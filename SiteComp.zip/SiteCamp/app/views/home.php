<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>EMIRA SPORTS</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="public/UI Kits/uikit.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
        <script src="js/uikit-icons.min.js"></script>
    </head>
    <div class="uk-container">
    <body bgcolor="#3ADF00">
    <center><img src="public/imagens/slogo.png" width="250" height="250"/></center>
    
    <br><br>

    <center><h1><font face="Verdana">Emira Championship</font></h1></center>
    <br><br>

    <div align="center">
    <table border="1" width="50%" bgcolor="#000000">
    <tr><td bgcolor="#82FA58"><h4><strong><center><font face="Garamond">"Este site é perfeito para você gerenciar seu<br>
    campeonato de futebol do seu jeito. Crie o seu agora mesmo.<br>

    Não se preocupe, vamos te guiar até a
    <br>conclusão do campeonato."</font></center></strong></h4></td></tr>
    </table>
    </div>

    <br><br>
   <div align="center">
    <center><a href="cadastro"><img src="public/imagens/logo.png" width="100" height="100"/></a></center>
    <br>
        <a href="cadastro"><button type="submit" class="uk-button">Criar um Torneio</button></a>
    </div>
    <br>
    </div>
</body>
</html>
